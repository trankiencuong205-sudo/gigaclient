# GIGA Client — expanded source

Original client-side Fabric utility GUI for Minecraft Java 1.21.11, Java 21.

## Included working code
- Right Shift opens a multi-category ClickGUI; module states persist to `config/giga/modules.properties`.
- HUD shows coordinates and FPS. Optional Spotify now-playing text appears when Spotify data is available.
- Waypoint creation stores coordinates in `config/giga/waypoints.csv`.
- Spotify integration uses OAuth PKCE and the real Spotify Web API for playback control on an active Spotify Connect device.
- GitHub Actions workflow builds the project and uploads the JAR artifact.

## Important implementation status
The GUI toggles are not proof that every named module is implemented. Combat automation, anti-cheat bypasses, multiplayer dupe exploits, and server-side base detection are not implemented. Block ESP, storage/hole/tunnel/sus-chunk scanning and in-world waypoint rendering still require dedicated implementation and compatibility testing. Do not treat these labels as working features yet. The Fullbright toggle currently adjusts gamma while enabled; it does not restore the previous gamma automatically.

## Build
Use Java 21 and run `gradle build` (or import the project into an environment with Fabric Loom and network access). Output is `build/libs/`. The repository currently does not include the Gradle wrapper. GitHub Actions installs Gradle and attempts the build. Dependency compatibility with the exact 1.21.11 release must be confirmed by a successful CI run.

## Spotify setup
1. Create an app in the [Spotify Developer Dashboard](https://developer.spotify.com/dashboard), if your account is eligible.
2. Add redirect URI exactly `http://127.0.0.1:8888/callback`.
3. Launch the mod once and set `client_id=YOUR_CLIENT_ID` in `config/giga/spotify.properties`.
4. Press Right Shift → Music → Connect Spotify.
5. Use an active Spotify device for playback controls. Spotify account eligibility, API restrictions and Premium requirements are controlled by Spotify and can change.

Tokens are stored locally in `config/giga/spotify-tokens.properties`. Never share this file or commit it. The mod controls Spotify; it does not decode or stream Spotify audio inside Minecraft.
