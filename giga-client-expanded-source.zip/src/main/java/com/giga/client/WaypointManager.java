package com.giga.client;
import java.nio.file.*;import java.util.*;
public final class WaypointManager {
 public record Waypoint(String name,int x,int y,int z){} private static final Path FILE=Path.of("config","giga","waypoints.csv"); private static final List<Waypoint> ITEMS=new ArrayList<>(); private static boolean loaded=false; private WaypointManager(){}
 private static void load(){if(loaded)return;loaded=true;try{if(Files.exists(FILE))for(String line:Files.readAllLines(FILE)){String[] p=line.split(",",4);if(p.length==4)ITEMS.add(new Waypoint(p[0],Integer.parseInt(p[1]),Integer.parseInt(p[2]),Integer.parseInt(p[3])));}}catch(Exception ignored){}}
 public static synchronized List<Waypoint> all(){load();return List.copyOf(ITEMS);} public static synchronized void add(String name,int x,int y,int z){load();ITEMS.add(new Waypoint(name.replace(","," "),x,y,z));save();}
 private static void save(){try{Files.createDirectories(FILE.getParent());List<String> lines=new ArrayList<>();for(Waypoint w:ITEMS)lines.add(w.name()+","+w.x()+","+w.y()+","+w.z());Files.write(FILE,lines);}catch(Exception ignored){}}
}
