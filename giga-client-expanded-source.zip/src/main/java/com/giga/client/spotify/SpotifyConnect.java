package com.giga.client.spotify;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.sun.net.httpserver.HttpServer;

/** Spotify Web API controller. Playback audio is provided by Spotify Connect, not Minecraft. */
public final class SpotifyConnect {
    private static final SpotifyConnect INSTANCE = new SpotifyConnect();
    private static final String API = "https://api.spotify.com/v1";
    private static final String TOKEN_URL = "https://accounts.spotify.com/api/token";
    private static final Gson GSON = new Gson();
    private final HttpClient http = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).build();
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "giga-spotify"); t.setDaemon(true); return t; });
    private final Path dir = Path.of("config", "giga");
    private final Path settingsFile = dir.resolve("spotify.properties");
    private final Path tokenFile = dir.resolve("spotify-token.json");
    private volatile String clientId = "";
    private volatile String accessToken = "";
    private volatile String refreshToken = "";
    private volatile long expiresAt = 0;
    private volatile String status = "Not connected";
    private volatile String currentTrack = "";

    private SpotifyConnect() { load(); }
    public static SpotifyConnect get() { return INSTANCE; }
    public String status() { return status; }
    public String currentTrack() { return currentTrack; }

    private void load() {
        try {
            Files.createDirectories(dir);
            Properties p = new Properties();
            if (Files.exists(settingsFile)) try (var in = Files.newInputStream(settingsFile)) { p.load(in); }
            clientId = p.getProperty("client_id", "").trim();
            if (Files.exists(tokenFile)) {
                JsonObject j = JsonParser.parseString(Files.readString(tokenFile)).getAsJsonObject();
                refreshToken = j.has("refresh_token") ? j.get("refresh_token").getAsString() : "";
                accessToken = j.has("access_token") ? j.get("access_token").getAsString() : "";
                expiresAt = j.has("expires_at") ? j.get("expires_at").getAsLong() : 0;
                status = refreshToken.isBlank() ? "Not connected" : "Saved Spotify session — checking…";
            }
        } catch (Exception e) { status = "Config error: " + e.getMessage(); }
    }

    public CompletableFuture<Void> connect() {
        return CompletableFuture.runAsync(() -> {
            try {
                if (clientId.isBlank()) { status = "Set client_id in config/giga/spotify.properties"; return; }
                byte[] random = new byte[64]; new SecureRandom().nextBytes(random);
                String verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(random);
                String challenge = Base64.getUrlEncoder().withoutPadding().encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
                String state = randomUrl(24);
                HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 8888), 0);
                server.createContext("/callback", exchange -> {
                    String query = exchange.getRequestURI().getRawQuery();
                    Map<String,String> q = parseQuery(query == null ? "" : query);
                    String body;
                    if (!state.equals(q.get("state"))) { body = "Login failed. State mismatch. You can close this tab."; status = "OAuth state mismatch"; }
                    else if (q.containsKey("error")) { body = "Spotify authorization denied. You can close this tab."; status = "Authorization denied: " + q.get("error"); }
                    else if (q.containsKey("code")) {
                        try { exchangeCode(q.get("code"), verifier); body = "Spotify connected. You can return to Minecraft."; }
                        catch (Exception e) { status = "Token exchange failed: " + e.getMessage(); body = "Spotify connection failed. Return to Minecraft for details."; }
                    } else { body = "Missing authorization code. Return to Minecraft."; status = "Missing OAuth code"; }
                    byte[] bytes = ("<!doctype html><meta charset=utf-8><title>GIGA Spotify</title><body style='font:16px sans-serif;background:#10131b;color:#fff;padding:3rem'>" + body + "</body>").getBytes(StandardCharsets.UTF_8);
                    exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8"); exchange.sendResponseHeaders(200, bytes.length); exchange.getResponseBody().write(bytes); exchange.close();
                    server.stop(0);
                });
                server.setExecutor(Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "giga-oauth-callback"); t.setDaemon(true); return t; }));
                server.start();
                String scope = "user-read-playback-state user-read-currently-playing user-modify-playback-state";
                String url = "https://accounts.spotify.com/authorize?response_type=code&client_id=" + enc(clientId) + "&redirect_uri=" + enc("http://127.0.0.1:8888/callback") + "&scope=" + enc(scope) + "&state=" + enc(state) + "&code_challenge_method=S256&code_challenge=" + enc(challenge);
                java.awt.Desktop.getDesktop().browse(URI.create(url));
                status = "Browser opened — approve Spotify access";
                // Callback server owns completion; browser/OAuth failures are shown in status.
            } catch (Exception e) { status = "OAuth error: " + e.getMessage(); }
        }, worker);
    }

    private synchronized void exchangeCode(String code, String verifier) throws Exception {
        JsonObject j = postForm(TOKEN_URL, "grant_type=authorization_code&code=" + enc(code) + "&redirect_uri=" + enc("http://127.0.0.1:8888/callback") + "&client_id=" + enc(clientId) + "&code_verifier=" + enc(verifier), false);
        acceptTokens(j, true);
        status = "Connected to Spotify";
    }
    private synchronized void refresh() throws Exception {
        if (refreshToken.isBlank()) throw new IOException("Connect Spotify first");
        JsonObject j = postForm(TOKEN_URL, "grant_type=refresh_token&refresh_token=" + enc(refreshToken) + "&client_id=" + enc(clientId), false);
        acceptTokens(j, false);
    }
    private void acceptTokens(JsonObject j, boolean initial) throws IOException {
        if (j.has("error")) throw new IOException(j.has("error_description") ? j.get("error_description").getAsString() : j.get("error").getAsString());
        accessToken = j.get("access_token").getAsString();
        if (j.has("refresh_token")) refreshToken = j.get("refresh_token").getAsString();
        expiresAt = Instant.now().getEpochSecond() + j.get("expires_in").getAsLong() - 30;
        JsonObject saved = new JsonObject(); saved.addProperty("access_token", accessToken); saved.addProperty("refresh_token", refreshToken); saved.addProperty("expires_at", expiresAt);
        Files.createDirectories(dir); Files.writeString(tokenFile, GSON.toJson(saved));
    }
    private synchronized String token() throws Exception { if (accessToken.isBlank() || Instant.now().getEpochSecond() >= expiresAt) refresh(); return accessToken; }
    private JsonObject postForm(String url, String form, boolean auth) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url)).header("Content-Type", "application/x-www-form-urlencoded").POST(HttpRequest.BodyPublishers.ofString(form));
        if (auth) b.header("Authorization", "Bearer " + token());
        HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
        if (r.statusCode() < 200 || r.statusCode() >= 300) throw new IOException("HTTP " + r.statusCode() + ": " + r.body());
        return JsonParser.parseString(r.body()).getAsJsonObject();
    }
    private HttpResponse<String> api(String method, String path, String body) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(API + path)).header("Authorization", "Bearer " + token());
        if (body != null) b.header("Content-Type", "application/json");
        switch (method) { case "PUT" -> b.PUT(body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(body)); case "POST" -> b.POST(body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(body)); case "GET" -> b.GET(); default -> throw new IllegalArgumentException("Unsupported method"); }
        HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
        if (r.statusCode() == 401) { synchronized (this) { refresh(); } return api(method, path, body); }
        if (r.statusCode() < 200 || r.statusCode() >= 300) throw new IOException("HTTP " + r.statusCode() + (r.body().isBlank() ? "" : ": " + r.body()));
        return r;
    }
    public CompletableFuture<Void> playPause() { return action(() -> { HttpResponse<String> r = api("GET", "/me/player", null); boolean playing = JsonParser.parseString(r.body()).getAsJsonObject().has("is_playing") && JsonParser.parseString(r.body()).getAsJsonObject().get("is_playing").getAsBoolean(); api("PUT", playing ? "/me/player/pause" : "/me/player/play", null); status = playing ? "Paused" : "Playback started"; }); }
    public CompletableFuture<Void> next() { return action(() -> { api("POST", "/me/player/next", null); status = "Skipped to next track"; }); }
    public CompletableFuture<Void> previous() { return action(() -> { api("POST", "/me/player/previous", null); status = "Previous track"; }); }
    public CompletableFuture<Void> volume(int percent) { int v = Math.max(0, Math.min(100, percent)); return action(() -> { api("PUT", "/me/player/volume?volume_percent=" + v, null); status = "Volume set to " + v + "%"; }); }
    public CompletableFuture<Void> refreshStatus() { return action(() -> { JsonObject j = JsonParser.parseString(api("GET", "/me/player/currently-playing", null).body()).getAsJsonObject(); if (!j.has("item") || j.get("item").isJsonNull()) currentTrack = "Nothing playing"; else { JsonObject item = j.getAsJsonObject("item"); currentTrack = item.get("name").getAsString() + " — " + item.getAsJsonArray("artists").get(0).getAsJsonObject().get("name").getAsString(); } status = "Connected · " + currentTrack; }); }
    public CompletableFuture<Void> searchAndPlay(String query) { return action(() -> { String path = "/search?type=track&limit=1&q=" + enc(query); JsonObject root = JsonParser.parseString(api("GET", path, null).body()).getAsJsonObject(); var items = root.getAsJsonObject("tracks").getAsJsonArray("items"); if (items.isEmpty()) { status = "No matching track"; return; } String uri = items.get(0).getAsJsonObject().get("uri").getAsString(); JsonObject body = new JsonObject(); body.addProperty("uris", ""); var uris = new com.google.gson.JsonArray(); uris.add(uri); body.add("uris", uris); api("PUT", "/me/player/play", GSON.toJson(body)); currentTrack = items.get(0).getAsJsonObject().get("name").getAsString(); status = "Requested: " + currentTrack; }); }
    private CompletableFuture<Void> action(Checked action) { return CompletableFuture.runAsync(() -> { try { action.run(); } catch (Exception e) { status = "Spotify: " + e.getMessage(); } }, worker); }
    @FunctionalInterface private interface Checked { void run() throws Exception; }
    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    private static String randomUrl(int bytes) { byte[] b = new byte[bytes]; new SecureRandom().nextBytes(b); return Base64.getUrlEncoder().withoutPadding().encodeToString(b); }
    private static Map<String,String> parseQuery(String query) { java.util.HashMap<String,String> m = new java.util.HashMap<>(); for (String pair : query.split("&")) { String[] p = pair.split("=",2); if (p.length == 2) m.put(java.net.URLDecoder.decode(p[0], StandardCharsets.UTF_8), java.net.URLDecoder.decode(p[1], StandardCharsets.UTF_8)); } return m; }
}
