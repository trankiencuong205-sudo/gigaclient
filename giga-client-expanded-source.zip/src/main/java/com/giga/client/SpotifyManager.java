package com.giga.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.awt.Desktop;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.Base64;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.sun.net.httpserver.HttpServer;

/** Real Spotify Web API integration. Playback is controlled on an existing Spotify Connect device. */
public final class SpotifyManager {
    private static final String REDIRECT_URI = "http://127.0.0.1:8888/callback";
    private static final String API = "https://api.spotify.com/v1";
    private static final String AUTH = "https://accounts.spotify.com/authorize";
    private static final String TOKEN = "https://accounts.spotify.com/api/token";
    private static final String SCOPES = "user-read-playback-state user-read-currently-playing user-modify-playback-state";
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(12)).build();
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "giga-spotify"); t.setDaemon(true); return t; });
    private static final Path DIR = Path.of("config", "giga");
    private static final Path CONFIG = DIR.resolve("spotify.properties");
    private static final Path TOKENS = DIR.resolve("spotify-tokens.properties");
    private static final SecureRandom RANDOM = new SecureRandom();

    private static volatile String clientId = "";
    private static volatile String accessToken = "";
    private static volatile String refreshToken = "";
    private static volatile long expiresAt = 0;
    private static volatile String status = "Not connected";
    private static volatile String track = "No track information";
    private static volatile String artist = "";
    private static volatile String device = "";
    private static volatile String searchResults = "Search Spotify for a track";
    private static volatile boolean busy = false;

    private SpotifyManager() {}
    public static String status() { return status; }
    public static String track() { return track; }
    public static String artist() { return artist; }
    public static String device() { return device; }
    public static String searchResults() { return searchResults; }
    public static boolean busy() { return busy; }

    public static void initialize() {
        try {
            Files.createDirectories(DIR);
            if (!Files.exists(CONFIG)) {
                Properties example = new Properties();
                example.setProperty("client_id", "YOUR_SPOTIFY_CLIENT_ID");
                try (var out = Files.newOutputStream(CONFIG)) { example.store(out, "Set client_id from the Spotify Developer Dashboard"); }
            }
            Properties cfg = load(CONFIG);
            clientId = cfg.getProperty("client_id", "").trim();
            if (clientId.equals("YOUR_SPOTIFY_CLIENT_ID")) clientId = "";
            Properties tokens = load(TOKENS);
            accessToken = tokens.getProperty("access_token", "");
            refreshToken = tokens.getProperty("refresh_token", "");
            expiresAt = Long.parseLong(tokens.getProperty("expires_at", "0"));
            if (!clientId.isBlank() && !accessToken.isBlank()) status = "Saved login loaded; checking Spotify…";
            else if (clientId.isBlank()) status = "Set Client ID in config/giga/spotify.properties";
        } catch (Exception e) { status = "Config error: " + concise(e); }
    }

    public static void connect() {
        run(() -> {
            if (clientId.isBlank()) { status = "Missing Client ID in config/giga/spotify.properties"; return; }
            String verifier = randomUrlSafe(64);
            String challenge = Base64.getUrlEncoder().withoutPadding().encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));
            String state = randomUrlSafe(24);
            HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 8888), 0);
            var result = new java.util.concurrent.CompletableFuture<String>();
            server.createContext("/callback", exchange -> {
                String query = exchange.getRequestURI().getRawQuery();
                String code = queryValue(query, "code");
                String gotState = queryValue(query, "state");
                String error = queryValue(query, "error");
                String body;
                if (error != null) { body = "Spotify authorization failed. You can close this tab."; result.completeExceptionally(new IOException(error)); }
                else if (code == null || !state.equals(gotState)) { body = "Invalid OAuth response. You can close this tab."; result.completeExceptionally(new IOException("OAuth state mismatch or missing code")); }
                else { body = "GIGA Client connected to Spotify. You can return to Minecraft."; result.complete(code); }
                byte[] bytes = ("<html><meta charset='utf-8'><title>GIGA Spotify</title><body style='font:16px sans-serif;background:#10151c;color:#e9fff2;padding:3rem'>" + body + "</body></html>").getBytes(StandardCharsets.UTF_8);
                exchange.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
                exchange.sendResponseHeaders(200, bytes.length); exchange.getResponseBody().write(bytes); exchange.close();
            });
            server.start();
            try {
                String url = AUTH + "?response_type=code&client_id=" + enc(clientId) + "&redirect_uri=" + enc(REDIRECT_URI) + "&scope=" + enc(SCOPES) + "&state=" + enc(state) + "&code_challenge_method=S256&code_challenge=" + enc(challenge);
                if (!Desktop.isDesktopSupported()) throw new IOException("Cannot open browser automatically; open the authorization URL manually: " + url);
                Desktop.getDesktop().browse(URI.create(url));
                status = "Waiting for Spotify authorization in browser…";
                String code = result.get();
                JsonObject token = postForm(TOKEN, "grant_type=authorization_code&code=" + enc(code) + "&redirect_uri=" + enc(REDIRECT_URI) + "&client_id=" + enc(clientId) + "&code_verifier=" + enc(verifier), null);
                storeTokens(token, true);
                status = "Spotify connected";
                refreshPlaybackNow();
            } finally { server.stop(0); }
        });
    }

    public static void refreshPlayback() { run(() -> { ensureToken(); refreshPlaybackNow(); }); }
    public static void playPause() { run(() -> { ensureToken(); JsonObject state = getJson(API + "/me/player"); String isPlaying = state == null ? "" : state.has("is_playing") ? state.get("is_playing").getAsString() : ""; apiRequest(isPlaying.equals("true") ? "PUT" : "PUT", API + (isPlaying.equals("true") ? "/me/player/pause" : "/me/player/play"), null); status = isPlaying.equals("true") ? "Pause requested" : "Play requested"; refreshPlaybackNow(); }); }
    public static void next() { run(() -> { ensureToken(); apiRequest("POST", API + "/me/player/next", null); status = "Next track requested"; refreshPlaybackNow(); }); }
    public static void previous() { run(() -> { ensureToken(); apiRequest("POST", API + "/me/player/previous", null); status = "Previous track requested"; refreshPlaybackNow(); }); }
    public static void search(String query) { run(() -> { ensureToken(); if (query.isBlank()) { searchResults = "Enter a track or artist name"; return; } JsonObject data = getJson(API + "/search?type=track&limit=1&q=" + enc(query)); JsonArray items = data.getAsJsonObject("tracks").getAsJsonArray("items"); if (items.isEmpty()) { searchResults = "No results"; return; } JsonObject first = items.get(0).getAsJsonObject(); String uri = first.get("uri").getAsString(); track = first.get("name").getAsString(); artist = first.getAsJsonArray("artists").get(0).getAsJsonObject().get("name").getAsString(); searchResults = track + " — " + artist; JsonObject body = new JsonObject(); JsonArray uris = new JsonArray(); uris.add(uri); body.add("uris", uris); apiRequest("PUT", API + "/me/player/play", body.toString()); status = "Play requested: " + searchResults; refreshPlaybackNow(); }); }

    private static void refreshPlaybackNow() throws Exception {
        JsonObject data = getJson(API + "/me/player");
        if (data == null) { status = "No active Spotify Connect device. Open Spotify on a device first."; device = "No active device"; return; }
        if (data.has("device") && data.get("device").isJsonObject()) device = data.getAsJsonObject("device").get("name").getAsString();
        if (data.has("item") && data.get("item").isJsonObject()) {
            JsonObject item = data.getAsJsonObject("item"); track = item.get("name").getAsString();
            JsonArray artists = item.getAsJsonArray("artists"); artist = artists.isEmpty() ? "" : artists.get(0).getAsJsonObject().get("name").getAsString();
            status = data.has("is_playing") && data.get("is_playing").getAsBoolean() ? "Playing" : "Paused";
        } else status = "Spotify connected; nothing is currently playing";
    }

    private static void ensureToken() throws Exception {
        if (clientId.isBlank()) throw new IOException("Missing Client ID in config/giga/spotify.properties");
        if (accessToken.isBlank()) throw new IOException("Not connected. Click Connect Spotify first.");
        if (System.currentTimeMillis() >= expiresAt - 60000) {
            if (refreshToken.isBlank()) throw new IOException("Session expired. Connect Spotify again.");
            JsonObject token = postForm(TOKEN, "grant_type=refresh_token&refresh_token=" + enc(refreshToken) + "&client_id=" + enc(clientId), null);
            storeTokens(token, false);
        }
    }
    private static JsonObject getJson(String url) throws Exception { HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15)).header("Authorization", "Bearer " + accessToken).GET().build(); HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString()); if (response.statusCode() == 204) return null; if (response.statusCode() < 200 || response.statusCode() >= 300) throw new IOException("Spotify API HTTP " + response.statusCode() + ": " + response.body()); return JsonParser.parseString(response.body()).getAsJsonObject(); }
    private static void apiRequest(String method, String url, String body) throws Exception { HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15)).header("Authorization", "Bearer " + accessToken); if (body == null) b.method(method, HttpRequest.BodyPublishers.noBody()); else b.header("Content-Type", "application/json").method(method, HttpRequest.BodyPublishers.ofString(body)); HttpResponse<String> r = HTTP.send(b.build(), HttpResponse.BodyHandlers.ofString()); if (r.statusCode() < 200 || r.statusCode() >= 300) throw new IOException("Spotify API HTTP " + r.statusCode() + ": " + r.body()); }
    private static JsonObject postForm(String url, String form, String ignored) throws Exception { HttpRequest req = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15)).header("Content-Type", "application/x-www-form-urlencoded").POST(HttpRequest.BodyPublishers.ofString(form)).build(); HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString()); if (res.statusCode() < 200 || res.statusCode() >= 300) throw new IOException("Spotify OAuth HTTP " + res.statusCode() + ": " + res.body()); return JsonParser.parseString(res.body()).getAsJsonObject(); }
    private static void storeTokens(JsonObject token, boolean initial) throws IOException { accessToken = token.get("access_token").getAsString(); if (token.has("refresh_token")) refreshToken = token.get("refresh_token").getAsString(); expiresAt = System.currentTimeMillis() + token.get("expires_in").getAsLong() * 1000L; Properties p = new Properties(); p.setProperty("access_token", accessToken); p.setProperty("refresh_token", refreshToken); p.setProperty("expires_at", Long.toString(expiresAt)); try (var out = Files.newOutputStream(TOKENS)) { p.store(out, "GIGA Spotify OAuth tokens. Do not share this file."); } }
    private static Properties load(Path p) throws IOException { Properties props = new Properties(); if (Files.exists(p)) try (var in = Files.newInputStream(p)) { props.load(in); } return props; }
    private static String randomUrlSafe(int bytes) { byte[] data = new byte[bytes]; RANDOM.nextBytes(data); return Base64.getUrlEncoder().withoutPadding().encodeToString(data); }
    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    private static String queryValue(String query, String key) { if (query == null) return null; for (String pair : query.split("&")) { String[] kv = pair.split("=", 2); if (kv.length == 2 && kv[0].equals(key)) return java.net.URLDecoder.decode(kv[1], StandardCharsets.UTF_8); } return null; }
    private static void run(ThrowingRunnable action) { if (busy) return; busy = true; WORKER.submit(() -> { try { action.run(); } catch (Exception e) { status = concise(e); } finally { busy = false; } }); }
    private static String concise(Exception e) { String m = e.getMessage(); return m == null ? e.getClass().getSimpleName() : m.length() > 110 ? m.substring(0, 107) + "…" : m; }
    @FunctionalInterface private interface ThrowingRunnable { void run() throws Exception; }
}
