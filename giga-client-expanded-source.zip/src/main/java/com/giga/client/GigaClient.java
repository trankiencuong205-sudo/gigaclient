package com.giga.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.nio.file.*;
import java.util.*;

public final class GigaClient implements ClientModInitializer {
    public static final List<ModuleState> MODULES = new ArrayList<>(List.of(
        new ModuleState("Aim Assist", "Combat", false), new ModuleState("Auto Clicker", "Combat", false), new ModuleState("Totem Helper", "Combat", false),
        new ModuleState("Auto Tool", "Misc", false), new ModuleState("Auto Reconnect", "Misc", false), new ModuleState("Fast Place", "Misc", false), new ModuleState("Inventory HUD", "Misc", true),
        new ModuleState("Hole ESP", "BaseFinding", false), new ModuleState("Light Finder", "BaseFinding", false), new ModuleState("Sus Chunk Finder", "BaseFinding", false), new ModuleState("Tunnel Finder", "BaseFinding", false), new ModuleState("Waypoints", "BaseFinding", true),
        new ModuleState("Block ESP", "Render", false), new ModuleState("Storage ESP", "Render", false), new ModuleState("Entity ESP", "Render", false), new ModuleState("Block Outline", "Render", true), new ModuleState("Fullbright", "Render", false), new ModuleState("HUD", "Render", true), new ModuleState("Coordinates", "Render", true), new ModuleState("FPS Counter", "Render", true), new ModuleState("Armor HUD", "Render", true),
        new ModuleState("Free Look", "World", false), new ModuleState("Zoom", "World", false), new ModuleState("Waypoint Beacons", "World", true),
        new ModuleState("Music HUD", "Client", true), new ModuleState("Animations", "Client", true), new ModuleState("Notifications", "Client", true)
    ));
    private static final Path CONFIG=Path.of("config","giga","modules.properties");
    private KeyBinding openGuiKey;
    @Override public void onInitializeClient() {
        loadConfig(); SpotifyManager.initialize();
        openGuiKey=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.giga.clickgui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));
        ClientTickEvents.END_CLIENT_TICK.register(client -> { while(openGuiKey.wasPressed()) if(client.currentScreen==null) client.setScreen(new GigaScreen()); });
        ClientTickEvents.END_CLIENT_TICK.register(client -> { if(client.player!=null && enabled("Fullbright")) client.options.getGamma().setValue(16.0); });
        HudRenderCallback.EVENT.register((ctx,tickCounter)->{
            MinecraftClient client=MinecraftClient.getInstance(); if(client.player==null||client.options.hudHidden||!enabled("HUD")) return;
            int x=7,y=7; ctx.fill(x,y,x+158,y+(enabled("Coordinates")?52:38),0xB910121C);
            ctx.drawText(client.textRenderer,Text.literal("GIGA CLIENT  §7/ 1.0.0"),x+6,y+5,0xFFB69CFF,true); y+=17;
            if(enabled("Coordinates")){var p=client.player.getBlockPos();ctx.drawText(client.textRenderer,Text.literal("XYZ  "+p.getX()+" / "+p.getY()+" / "+p.getZ()),x+6,y,0xFFF2F2FA,true);y+=12;}
            if(enabled("FPS Counter")) ctx.drawText(client.textRenderer,Text.literal("FPS  "+client.getCurrentFps()),x+6,y,0xFF68DDB4,true);
            if(enabled("Music HUD") && !SpotifyManager.track().equals("No track information")){ctx.fill(client.getWindow().getScaledWidth()-210,8,client.getWindow().getScaledWidth()-8,43,0xD911171B);ctx.fill(client.getWindow().getScaledWidth()-210,8,client.getWindow().getScaledWidth()-207,43,0xFF1ED760);ctx.drawText(client.textRenderer,Text.literal("NOW PLAYING"),client.getWindow().getScaledWidth()-200,13,0xFF1ED760,true);ctx.drawText(client.textRenderer,Text.literal(trim(SpotifyManager.track(),25)),client.getWindow().getScaledWidth()-200,25,0xFFFFFFFF,true);}
        });
    }
    public static boolean enabled(String name){return MODULES.stream().filter(m->m.name().equals(name)).findFirst().map(ModuleState::enabled).orElse(false);}
    public static void saveConfig(){try{Files.createDirectories(CONFIG.getParent());Properties p=new Properties();for(ModuleState m:MODULES)p.setProperty(m.name(),Boolean.toString(m.enabled()));try(var out=Files.newOutputStream(CONFIG)){p.store(out,"GIGA module states");}}catch(Exception ignored){}}
    private static void loadConfig(){try{if(!Files.exists(CONFIG))return;Properties p=new Properties();try(var in=Files.newInputStream(CONFIG)){p.load(in);}for(ModuleState m:MODULES)m.setEnabled(Boolean.parseBoolean(p.getProperty(m.name(),Boolean.toString(m.enabled()))));}catch(Exception ignored){}}
    private static String trim(String s,int n){return s.length()<=n?s:s.substring(0,n-1)+"…";}
}
