package com.giga.client;

public final class ModuleState {
    private final String name;
    private final String category;
    private boolean enabled;
    public ModuleState(String name, String category, boolean enabled) { this.name=name; this.category=category; this.enabled=enabled; }
    public String name(){return name;} public String category(){return category;} public boolean enabled(){return enabled;}
    public void toggle(){enabled=!enabled; GigaClient.saveConfig();} public void setEnabled(boolean value){enabled=value;}
}
