package com.giga.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import java.util.*;

public final class GigaScreen extends Screen {
    private static final int[] COLORS={0xFF61B6FF,0xFFB69CFF,0xFF68DDB4,0xFFFFC16B,0xFFFF7D9D,0xFF9EA8FF};
    private static final List<String> CATEGORIES=List.of("Combat","Misc","Donut","BaseFinding","Render","World","Client");
    private int left,top,panelWidth,panelHeight,scroll=0; private TextFieldWidget search; private String filter="";
    public GigaScreen(){super(Text.literal("GIGA Client"));}
    @Override protected void init(){ rebuild(); }
    private void rebuild(){clearChildren();panelWidth=Math.min(166,Math.max(118,(width-24)/3));int gap=6;int columns=Math.min(CATEGORIES.size(),Math.max(1,(width-20)/(panelWidth+gap)));panelHeight=Math.min(height-62,440);left=(width-(columns*panelWidth+(columns-1)*gap))/2;top=Math.max(26,(height-panelHeight)/2);
        search=new TextFieldWidget(textRenderer,left,top-24,Math.min(230,width-20),18,Text.literal("Search modules"));search.setPlaceholder(Text.literal("Search modules…"));search.setText(filter);search.setChangedListener(s->{filter=s;rebuild();});addDrawableChild(search);
        for(int c=0;c<columns;c++){String cat=CATEGORIES.get(c);int x=left+c*(panelWidth+gap),y=top+34;for(ModuleState m:GigaClient.MODULES){if(!m.category().equals(cat)||!m.name().toLowerCase(Locale.ROOT).contains(filter.toLowerCase(Locale.ROOT)))continue;if(y+20>top+panelHeight-24)break;ModuleState current=m;addDrawableChild(ButtonWidget.builder(label(current),b->{current.toggle();b.setMessage(label(current));}).dimensions(x+5,y,panelWidth-10,19).build());y+=22;}}
        addDrawableChild(ButtonWidget.builder(Text.literal("MUSIC ♫"),b->client.setScreen(new SpotifyScreen())).dimensions(left,top+panelHeight+5,85,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("ADD WAYPOINT"),b->{if(client.player!=null){WaypointManager.add("Waypoint "+(WaypointManager.all().size()+1),client.player.getBlockPos().getX(),client.player.getBlockPos().getY(),client.player.getBlockPos().getZ());}}).dimensions(left+90,top+panelHeight+5,110,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("CLOSE ×"),b->close()).dimensions(width-78,top+panelHeight+5,72,20).build());}
    private Text label(ModuleState m){return Text.literal((m.enabled()?"●  ":"○  ")+m.name());}
    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta){ctx.fill(0,0,width,height,0x85050810);int gap=6,columns=Math.min(CATEGORIES.size(),Math.max(1,(width-20)/(panelWidth+gap)));for(int c=0;c<columns;c++){int x=left+c*(panelWidth+gap);ctx.fill(x,top,x+panelWidth,top+panelHeight,0xEF161922);ctx.fill(x,top,x+panelWidth,top+2,COLORS[c%COLORS.length]);ctx.drawText(textRenderer,CATEGORIES.get(c),x+7,top+11,0xFFF4F5FF,true);ctx.drawText(textRenderer,"MODULES",x+7,top+23,0xFF737B8F,false);}ctx.drawText(textRenderer,"G I G A  /  MODULAR CLIENT",left,top-36,0xFFB69CFF,true);super.render(ctx,mouseX,mouseY,delta);}
    @Override public boolean mouseScrolled(double mouseX,double mouseY,double horizontalAmount,double verticalAmount){scroll+=(int)verticalAmount;return super.mouseScrolled(mouseX,mouseY,horizontalAmount,verticalAmount);}
    @Override public boolean shouldPause(){return false;}
}
