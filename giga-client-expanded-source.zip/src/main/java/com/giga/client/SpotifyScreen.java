package com.giga.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public final class SpotifyScreen extends Screen {
    private TextFieldWidget search;
    private String message = "";
    public SpotifyScreen() { super(Text.literal("GIGA Music / Spotify")); }
    @Override protected void init() {
        int w = Math.min(390, width - 28), x = (width - w) / 2, y = Math.max(24, (height - 300) / 2);
        search = new TextFieldWidget(textRenderer, x + 20, y + 106, w - 40, 20, Text.literal("Search Spotify"));
        search.setPlaceholder(Text.literal("Track or artist…")); addDrawableChild(search);
        addDrawableChild(ButtonWidget.builder(Text.literal("CONNECT SPOTIFY"), b -> { SpotifyManager.connect(); message = "Opening Spotify authorization in browser…"; })
            .dimensions(x + 20, y + 42, w - 40, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("SEARCH + PLAY"), b -> { SpotifyManager.search(search.getText()); message = "Searching Spotify…"; })
            .dimensions(x + 20, y + 132, w - 40, 22).build());
        int bw = (w - 52) / 3;
        addDrawableChild(ButtonWidget.builder(Text.literal("PREVIOUS"), b -> SpotifyManager.previous()).dimensions(x + 20, y + 166, bw, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("PLAY / PAUSE"), b -> SpotifyManager.playPause()).dimensions(x + 26 + bw, y + 166, bw, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("NEXT"), b -> SpotifyManager.next()).dimensions(x + 32 + bw * 2, y + 166, bw, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("REFRESH STATUS"), b -> SpotifyManager.refreshPlayback()).dimensions(x + 20, y + 198, w - 40, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("BACK"), b -> close()).dimensions(x + 20, y + 270, w - 40, 20).build());
    }
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xB5080C12);
        int w = Math.min(390, width - 28), x = (width - w) / 2, y = Math.max(24, (height - 300) / 2);
        ctx.fill(x, y, x + w, y + 300, 0xF0141D24); ctx.fill(x, y, x + w, y + 3, 0xFF1DB954);
        ctx.drawText(textRenderer, "GIGA MUSIC", x + 20, y + 14, 0xFF1ED760, true);
        ctx.drawText(textRenderer, "Spotify Connect · real account playback", x + 20, y + 29, 0xFFB8C5D1, false);
        ctx.drawText(textRenderer, "Track: " + clip(SpotifyManager.track(), 44), x + 20, y + 76, 0xFFF4F7FA, false);
        ctx.drawText(textRenderer, "Artist: " + clip(SpotifyManager.artist(), 44), x + 20, y + 89, 0xFFB8C5D1, false);
        ctx.drawText(textRenderer, "Device: " + clip(SpotifyManager.device(), 44), x + 20, y + 244, 0xFFB8C5D1, false);
        ctx.drawText(textRenderer, "Status: " + clip(SpotifyManager.status(), 52), x + 20, y + 257, 0xFF1ED760, false);
        super.render(ctx, mouseX, mouseY, delta);
    }
    private String clip(String s, int n) { return s.length() <= n ? s : s.substring(0, n - 1) + "…"; }
    @Override public boolean shouldPause() { return false; }
}
