package com.giga.client;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class GigaClient implements ClientModInitializer {
    public static final String MOD_ID = "giga";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("GIGA Client initialized. Build and runtime compatibility must be verified in CI/game.");
    }
}
