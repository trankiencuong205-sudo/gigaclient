# GIGA Client — clean build foundation

Minecraft Java 1.21.11, Fabric client mod, Java 21.

## What's included
- Minimal valid Fabric client entrypoint.
- Gradle/Loom project configuration.
- `fabric.mod.json` metadata.
- GitHub Actions workflow that installs Gradle, builds, and uploads the JAR.
- Workflow checks the expected project files before building.

## Build on GitHub
1. Upload the contents of this folder to the root of your `gigaclient` repository, keeping `.github/workflows/build.yml` at that exact path.
2. Commit to `main`.
3. Open Actions and select `Build GIGA Client`.
4. Download `GIGA-Client-JAR` from a successful run's Artifacts section.

## Important status
This is a clean build foundation, not the promised full feature client. It does not yet implement ESP, base finding, combat automation, dupe exploits, or Spotify playback. A successful CI run is required to confirm the selected Minecraft/Loom dependency versions resolve correctly. Do not label features complete until implemented and tested in-game.
